'use strict';
(() => {
 const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
 const targets = [...document.querySelectorAll('.reveal')];
 document.querySelectorAll('.research-copy,.showcase-copy').forEach(group => {
  [...group.children].forEach((child, index) => child.style.setProperty('--entry-index', Math.min(index, 5)));
 });
 let observer;
 if ('IntersectionObserver' in window && !reduced.matches) {
  observer = new IntersectionObserver(entries => entries.forEach(({target, isIntersecting}) => {
   if (!isIntersecting) return;
   target.classList.remove('garden-pending');
   target.classList.add('garden-enter');
   observer.unobserve(target);
  }), {rootMargin: '0px 0px -30px 0px', threshold: 0});
  targets.forEach(target => {
   if (target.getBoundingClientRect().top > innerHeight) target.classList.add('garden-pending');
   observer.observe(target);
  });
 }
 const frames = [...document.querySelectorAll('.thorn-frame')];
 let scheduled = false;
 function drift() {
  scheduled = false;
  if (reduced.matches) return;
  frames.forEach(frame => {
   const bounds = frame.getBoundingClientRect();
   if (bounds.bottom < 0 || bounds.top > innerHeight) return;
   const offset = Math.max(-8, Math.min(8, (bounds.top - innerHeight / 2) * .018));
   frame.style.setProperty('--thorn-drift', `${offset.toFixed(1)}px`);
  });
 }
 window.addEventListener('scroll', () => {
  if (!scheduled && !reduced.matches) { scheduled = true; requestAnimationFrame(drift); }
 }, {passive: true});
 reduced.addEventListener('change', () => {
  if (!reduced.matches) return;
  observer?.disconnect();
  targets.forEach(target => target.classList.remove('garden-pending', 'garden-enter'));
  frames.forEach(frame => frame.style.removeProperty('--thorn-drift'));
 });
 document.addEventListener('focusin', event => {
  const target = event.target.closest('.garden-pending');
  if (target) { target.classList.remove('garden-pending'); observer?.unobserve(target); }
 });
})();
