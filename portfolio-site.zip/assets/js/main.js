'use strict';
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('#nav');
function closeMenu(){nav?.classList.remove('open');menu?.setAttribute('aria-expanded','false');}
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open);});
nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav?.classList.contains('open')){closeMenu();menu.focus();}});
if ('IntersectionObserver' in window && !reduceMotion.matches){
 document.body.classList.add('motion-enabled');
 const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>entry.target.classList.toggle('is-out',!entry.isIntersecting));},{threshold:0,rootMargin:'25px 0px 25px 0px'});
 document.querySelectorAll('.reveal').forEach(el=>{if(el.getBoundingClientRect().top>innerHeight)el.classList.add('is-out');observer.observe(el);});
 reduceMotion.addEventListener('change',e=>{if(e.matches){observer.disconnect();document.body.classList.remove('motion-enabled');}});
}
const filters=document.querySelectorAll('[data-filter]');
filters.forEach(button=>button.addEventListener('click',()=>{
 filters.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
 let count=0;
 document.querySelectorAll('#featured-grid .project-card').forEach(card=>{const show=button.dataset.filter==='all'||card.dataset.category===button.dataset.filter;card.hidden=!show;if(show)count++;});
 document.querySelector('#filter-status').textContent=`${count} proyectos visibles.`;
}));
const tabs=document.querySelectorAll('.project-tabs a');
if(tabs.length&&'IntersectionObserver' in window){const sections=[...tabs].map(a=>document.querySelector(a.getAttribute('href'))).filter(Boolean);const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){tabs.forEach(a=>{if(a.hash==='#'+e.target.id)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current');});}});},{rootMargin:'-15% 0px -55% 0px'});sections.forEach(s=>observer.observe(s));}
// Project galleries: keyboard-accessible enlargement with native focus trapping.
const galleryButtons=[...document.querySelectorAll('[data-image]')];
if(galleryButtons.length){
 const dialog=document.createElement('dialog');
 dialog.className='image-dialog';
 dialog.setAttribute('aria-label','Galería del proyecto');
 dialog.innerHTML='<button class="lightbox-close" aria-label="Cerrar imagen">Cerrar ×</button><div class="lightbox-body"><button class="lightbox-prev" aria-label="Imagen anterior">←</button><figure><img alt=""><figcaption id="lightbox-caption"></figcaption></figure><button class="lightbox-next" aria-label="Imagen siguiente">→</button></div><p class="lightbox-counter mono" aria-live="polite"></p>';
 document.body.append(dialog);
 let index=0;
 const fullImage=dialog.querySelector('img');
 function showImage(next){
  index=(next+galleryButtons.length)%galleryButtons.length;
  const source=galleryButtons[index];
  fullImage.src=reduceMotion.matches&&source.dataset.image.endsWith('vibi-idle.webp')?source.dataset.image.replace('vibi-idle.webp','vibi-idle-still.webp'):source.dataset.image;
  fullImage.alt=source.dataset.caption;
  dialog.querySelector('figcaption').textContent=source.dataset.caption;
  dialog.querySelector('.lightbox-counter').textContent=`${index+1} / ${galleryButtons.length}`;
 }
 galleryButtons.forEach((button,i)=>button.addEventListener('click',()=>{showImage(i);dialog.showModal();document.body.classList.add('gallery-open');}));
 dialog.querySelector('.lightbox-close').addEventListener('click',()=>dialog.close());
 dialog.querySelector('.lightbox-prev').addEventListener('click',()=>showImage(index-1));
 dialog.querySelector('.lightbox-next').addEventListener('click',()=>showImage(index+1));
 dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();showImage(index+1);}if(e.key==='ArrowLeft'){e.preventDefault();showImage(index-1);}});
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
 dialog.addEventListener('close',()=>document.body.classList.remove('gallery-open'));
}
function updateAnimatedImages(){document.querySelectorAll('img').forEach(img=>{if(reduceMotion.matches&&img.src.endsWith('/vibi-idle.webp')){img.dataset.animatedSrc=img.src;img.src=img.src.replace('vibi-idle.webp','vibi-idle-still.webp');}else if(!reduceMotion.matches&&img.dataset.animatedSrc){img.src=img.dataset.animatedSrc;delete img.dataset.animatedSrc;}});}
updateAnimatedImages();reduceMotion.addEventListener('change',updateAnimatedImages);

// Guided architecture diagrams. They describe the system; they do not run it.
document.querySelectorAll('[data-flow]').forEach(explorer=>{
 const steps=[...explorer.querySelectorAll('[data-flow-step]')];
 const play=explorer.querySelector('[data-flow-play]');
 const caption=explorer.querySelector('.flow-caption p');
 const number=explorer.querySelector('.flow-caption-number');
 let timer=null;
 let current=0;
 function select(index){
  current=index;
  steps.forEach((step,i)=>{step.classList.toggle('active',i===index);step.setAttribute('aria-pressed',String(i===index));});
  caption.textContent=steps[index].dataset.flowDescription;
  number.textContent=`${String(index+1).padStart(2,'0')} / ${String(steps.length).padStart(2,'0')}`;
 }
 function stop(){clearInterval(timer);timer=null;play.innerHTML='Recorrer flujo <span aria-hidden="true">↗</span>';play.setAttribute('aria-label','Recorrer flujo');}
 steps.forEach((step,i)=>step.addEventListener('click',()=>{stop();select(i);}));
 play.addEventListener('click',()=>{
  if(timer){stop();return;}
  if(reduceMotion.matches){select((current+1)%steps.length);return;}
  select(0);
  play.innerHTML='Pausar recorrido <span aria-hidden="true">Ⅱ</span>';
  play.setAttribute('aria-label','Pausar recorrido');
  timer=setInterval(()=>{if(current>=steps.length-1){stop();return;}select(current+1);},1400);
 });
 reduceMotion.addEventListener('change',()=>stop());
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
});
